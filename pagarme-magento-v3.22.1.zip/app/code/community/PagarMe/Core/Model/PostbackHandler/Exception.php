<?php

class PagarMe_Core_Model_PostbackHandler_Exception extends \Exception
{
}
