<?php

class PagarMe_Core_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup
{
}
