<?php

require_once 'AbstractPostbackController.php';

/**
 * @codeCoverageIgnore
 */
class PagarMe_Core_Transaction_CreditcardController extends
 PagarMe_Core_Transaction_AbstractPostbackController
{
}
