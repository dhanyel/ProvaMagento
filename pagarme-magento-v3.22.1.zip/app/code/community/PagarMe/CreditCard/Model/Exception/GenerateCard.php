<?php
/**
 * @author LeonamDias <leonam.pd@gmail.com>
 * @package PHP
 */

class PagarMe_CreditCard_Model_Exception_GenerateCard extends \Exception
{
}
