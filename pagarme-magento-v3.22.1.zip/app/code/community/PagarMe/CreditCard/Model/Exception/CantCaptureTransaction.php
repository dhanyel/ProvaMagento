<?php

class PagarMe_CreditCard_Model_Exception_CantCaptureTransaction extends \Exception
{
}
