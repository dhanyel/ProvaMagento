<?php

class PagarMe_Card extends PagarMe_CardHashCommon {
}
