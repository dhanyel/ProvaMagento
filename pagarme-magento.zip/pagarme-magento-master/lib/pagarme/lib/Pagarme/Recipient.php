<?php

class PagarMe_Recipient extends PagarMe_Model {
}
