<?php
/*
 * @copyright   Copyright (C) 2015 Gamuza Technologies (http://www.gamuza.com.br/)
 * @author     Eneias Ramos de Melo <eneias@gamuza.com.br>
 */

class Inovarti_Pagarme_Block_Checkout_Totals_Fee
extends Mage_Checkout_Block_Total_Default
{
    /**
     * Use your own template if necessary
     * See "checkout/total/default.phtml" for model
     */
    // protected $_template = 'pagarme/checkout/total/fee.phtml';
}

