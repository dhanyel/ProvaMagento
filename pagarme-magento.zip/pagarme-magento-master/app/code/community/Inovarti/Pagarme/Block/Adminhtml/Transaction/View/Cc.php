<?php
/**
 *
 * @category   Inovarti
 * @package    Inovarti_Pagarme
 * @author     Suporte <suporte@inovarti.com.br>
 */

class Inovarti_Pagarme_Block_Adminhtml_Transaction_View_Cc extends Inovarti_Pagarme_Block_Adminhtml_Transaction_View_Abstract
{
    protected $_viewBlockType = 'cc';
}